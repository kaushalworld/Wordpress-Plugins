<?php
/**
 * Footer file in case of the elementor way
 */

?>

<?php do_action( 'exad_hf_footer' ); ?>
<?php wp_footer(); ?>
</body>
</html> 
