<div class="wpra-license-alert-wrap">
	<div class="wpra-license-alert">
    	<img src="<?php echo WPRA\Helpers\Utils::getAsset('images/logo_stacked.svg');?>" alt="WP Reactions">
    	<p>To activate your emoji reactions you must have a valid license key. To dismiss all banners, close this box and they will go away.</p>
    	<span class="dismiss-alert">&times;</span>
    	<a target="blank" class="btn-buy-now" href="https://wpreactions.com/pricing">Buy Now</a>
	</div>
</div>