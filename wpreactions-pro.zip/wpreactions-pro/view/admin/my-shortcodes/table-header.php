<tr>
    <th scope="col"><?php _e( 'ID', 'wpreactions' ); ?></th>
    <th scope="col"><?php _e( 'Post Type', 'wpreactions' ); ?></th>
    <th scope="col"><?php _e( 'Name', 'wpreactions' ); ?></th>
    <th scope="col"><?php _e( 'Shortcode', 'wpreactions' ); ?></th>
    <th class="text-center" scope="col"><?php _e( 'View', 'wpreactions' ); ?></th>
    <th class="text-center" scope="col"><?php _e( 'Edit', 'wpreactions' ); ?></th>
    <th class="text-center" scope="col"><?php _e( 'Clone', 'wpreactions' ); ?></th>
    <th class="text-center" scope="col"><?php _e( 'Delete', 'wpreactions' ); ?></th>
</tr>