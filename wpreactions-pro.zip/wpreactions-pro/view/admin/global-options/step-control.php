<div class="step-controls active">
    <button class="btn btn-secondary prev">
        <i class="qa qa-chevron-left mr-2"></i>
        <span><?php _e( 'Go Back', 'wpreactions' ); ?></span>
    </button>
    <button class="btn btn-secondary save-wpj-options">
        <i class="qa qa-check mr-2"></i>
        <span><?php _e( 'Save', 'wpreactions' ); ?></span>
    </button>
    <button class="btn btn-secondary next">
        <span><?php _e( 'Next', 'wpreactions' ); ?></span>
        <i class="qa qa-chevron-right ml-2"></i>
    </button>
</div>
