<?php

use WPRA\Helpers\OptionBlock;

OptionBlock::render('animation-state');
OptionBlock::render('call-to-action');
OptionBlock::render('counters');
OptionBlock::render('random-fake-counts');
OptionBlock::render('emoji-labels-basic');
OptionBlock::render('reaction-container');
OptionBlock::render('flying-animation');
OptionBlock::render('post-types');
OptionBlock::render('placement');

