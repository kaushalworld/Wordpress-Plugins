<?php

use WPRA\Helpers\OptionBlock;

OptionBlock::render('animation-state');
OptionBlock::render('call-to-action');
OptionBlock::render('progress-bars');
OptionBlock::render('random-fake-counts');
OptionBlock::render('emoji-labels');
OptionBlock::render('flying-animation');
OptionBlock::render('post-types');
OptionBlock::render('placement');

