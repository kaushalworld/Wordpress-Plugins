<?php

use WPRA\Helpers\Utils;

?>
<div class="row">
    <div class="col-md-12 text-center wpra-step-finish">
        <div class="option-wrap">
            <?php Utils::tooltip('step-finish'); ?>
            <div id="review-and-save"></div>
        </div>
    </div>
</div>