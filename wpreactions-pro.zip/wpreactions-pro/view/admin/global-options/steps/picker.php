<?php
use WPRA\Helpers\OptionBlock;
OptionBlock::render('emoji-picker');