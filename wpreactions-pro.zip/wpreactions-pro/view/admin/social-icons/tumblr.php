<?php if ( ! isset( $color ) ) return; ?>
<svg viewBox="0 0 170 170" xmlns="http://www.w3.org/2000/svg" fill="<?php echo $color; ?>">
    <g fill-rule="evenodd">
        <path d="m103.5,164.65c-24,0 -41.8,-12.3 -41.8,-41.8l0,-47.2l-21.8,0l0,-25.6c24,-6.2 34,-26.8 35.1,-44.7l24.9,0l0,40.6l29,0l0,29.7l-29,0l0,41.1c0,12.3 6.2,16.6 16.1,16.6l14.1,0l0,31.3l-26.6,0z"/>
    </g>
</svg>