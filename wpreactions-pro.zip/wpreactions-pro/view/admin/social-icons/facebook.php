<?php if(!isset($color)) return; ?>
<svg id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 200 200" xml:space="preserve" fill="<?php echo $color; ?>">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M78.02,187.7l35.12,0l0-87.94l24.5,0l2.61-29.44l-27.11,0c0,0,0-11,0-16.77
	c0-6.94,1.39-9.69,8.11-9.69c5.4,0,19.01,0,19.01,0V13.3c0,0-20.04,0-24.32,0c-26.13,0-37.91,11.51-37.91,33.54
	c0,19.19,0,23.48,0,23.48l-18.27,0l0,29.82l18.27,0L78.02,187.7z"/>
</svg>