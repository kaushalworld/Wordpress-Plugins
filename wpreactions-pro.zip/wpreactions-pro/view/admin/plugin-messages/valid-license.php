<br>
<span style="color:#2271b1;font-size:13px;margin: 15px 0 0 0;display: inline-block;">
    <span class="dashicons dashicons-info" style="margin-right: 3px;"></span>
    <span><?php _e('Please update to latest version to get new features and always best performance', 'wpreactions'); ?></span>
</span>
