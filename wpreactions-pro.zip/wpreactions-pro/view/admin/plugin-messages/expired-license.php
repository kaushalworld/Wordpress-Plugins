<br>
<span style="color:#b88944;font-size:14px;margin: 15px 0 0 0;display: inline-block;">
    <span class="dashicons dashicons-info" style="margin-right: 3px;"></span>
    <span><?php echo sprintf(
            __( "Your license is currently expired. Please %s to get VIP support and automatic updates.", 'wpreactions' ),
            '<a style="text-decoration: none;" target="_blank" href="https://wpreactions.com/account/">' .__('renew your license', 'wpreactions'). '</a>'
        ); ?>
    </span>
</span>
