<br>
<span style="color:#d63638;font-size:14px;margin: 15px 0 0 0;display: inline-block;">
    <span class="dashicons dashicons-warning" style="margin-right: 3px;"></span>
    <span><?php echo sprintf(
		    __( "Your license is invalid or not exists. Please %s to use plugin.", 'wpreactions' ),
		    '<a style="text-decoration: none;" target="_blank" href="https://wpreactions.com/pricing/">' .__('buy new license', 'wpreactions'). '</a>'
	    ); ?>
    </span>
</span>
