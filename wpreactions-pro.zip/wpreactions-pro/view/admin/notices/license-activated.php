<div class="notice-success notice wpra-notice is-dismissible" data-id="success_license_activation">
    <span><strong>WP Reactions Pro:</strong> Your license activated successfully</span>
</div>