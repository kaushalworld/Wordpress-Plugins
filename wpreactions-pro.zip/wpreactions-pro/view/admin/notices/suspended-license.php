<div class="notice-error notice wpra-notice" data-id="suspended_license">
	<div>
		<span><strong>WP Reactions Pro:</strong> Your license has been suspended due to 14 days of inactivity. If this was done in error, please contact </span>
		<a href="https://support.wpreactions.com" target="_blank">customer support.</a>
	</div>
</div>