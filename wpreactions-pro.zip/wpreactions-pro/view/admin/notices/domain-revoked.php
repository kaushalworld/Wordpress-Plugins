<div class="notice-success notice wpra-notice is-dismissible" data-id="success_revoke_domain">
    <span><strong>WP Reactions Pro:</strong> You revoked license key from this domain successfully</span>
</div>