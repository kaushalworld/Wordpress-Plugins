<div class="notice-error notice wpra-notice" data-id="revoked_license">
	<div>
		<span><strong>WP Reactions Pro:</strong> Your license has been revoked and is no longer active. If this was done in error, please contact to </span>
		<a href="https://support.wpreactions.com" target="_blank">customer support.</a>
	</div>
</div>