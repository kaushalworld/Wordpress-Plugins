<div class="notice-error notice wpra-notice" data-id="invalid_license">
	<div>
		<span><strong>WP Reactions Pro:</strong> Your license is invalid or not activated. If this was done in error, please contact to </span>
        <a href="https://support.wpreactions.com" target="_blank">customer support.</a>
	</div>
</div>