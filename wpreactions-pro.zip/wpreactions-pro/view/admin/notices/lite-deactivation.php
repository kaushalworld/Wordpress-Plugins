<div class="notice-warning notice wpra-notice is-dismissible" data-id="lite_deactivation">
    <span><strong>WP Reactions Lite</strong> version disabled due to WP Reactions Pro version activation.</span>
</div>