<div class="notice-warning notice wpra-notice" data-id="expired_license">
	<div>
		<span><strong>WP Reactions Pro:</strong> Your license is currently expired. Auto updates and VIP Support are no longer available. To renew your WP Reactions Pro License, please visit <a href="https://wpreactions.com/account/" target="_blank">your account</a> to renew.</span>
	</div>
</div>