<div class="loading-overlay active">
	<div class="loading-overlay-bg"></div>
	<div class="overlay-center">
		<div class="wpra-spinner"></div>
		<div class="overlay-message"><?php _e('Please wait...', 'wpreactions'); ?></div>
	</div>
</div>