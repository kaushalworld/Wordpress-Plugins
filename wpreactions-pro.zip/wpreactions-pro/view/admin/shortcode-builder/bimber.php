<?php

use WPRA\Helpers\Utils;
use WPRA\Helpers\OptionBlock;

OptionBlock::render('your-emojis-set');
OptionBlock::render('animation-state');
OptionBlock::render('call-to-action');
OptionBlock::render('fake-counts');
OptionBlock::render('progress-bars');
OptionBlock::render('emoji-labels');
OptionBlock::render('flying-animation');
OptionBlock::render('social-picker');
OptionBlock::render('share-counter');
OptionBlock::render('social-buttons-style');
OptionBlock::render('social-buttons-behavior');
OptionBlock::render('alignment');