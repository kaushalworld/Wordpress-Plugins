<?php

use WPRA\Helpers\Utils;
use WPRA\Helpers\OptionBlock;

OptionBlock::render('your-emojis-set');
OptionBlock::render('animation-state');
OptionBlock::render('call-to-action');
OptionBlock::render('counters-click');
OptionBlock::render('total-counter');
OptionBlock::render('emoji-labels-basic');
OptionBlock::render('reaction-container');
OptionBlock::render('fake-counts');
OptionBlock::render('flying-animation');
OptionBlock::render('social-picker');
OptionBlock::render('share-counter');
OptionBlock::render('social-buttons-style');
OptionBlock::render('social-buttons-behavior');
OptionBlock::render('alignment');