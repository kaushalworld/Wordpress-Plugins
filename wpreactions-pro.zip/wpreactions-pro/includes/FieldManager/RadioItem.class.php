<?php

namespace WPRA\FieldManager;

class RadioItem extends Field {

    public static function create() {
        return new self();
    }
}
