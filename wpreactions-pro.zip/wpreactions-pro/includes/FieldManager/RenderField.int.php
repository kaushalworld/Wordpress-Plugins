<?php

namespace WPRA\FieldManager;

interface RenderField {
    public function render();
}