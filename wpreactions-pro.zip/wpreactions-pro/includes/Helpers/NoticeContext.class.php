<?php

namespace WPRA\Helpers;

class NoticeContext {
	const ALL = 1;
	const DASHBOARD = 2;
	const PLUGIN = 3;
}