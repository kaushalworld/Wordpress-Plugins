=== The Plus Addons for Elementor ===
Contributors: posimyththemes, nirmalkavaiya, devangvachheta, sagarpatel124
Tags: Elementor, elementor widgets, elements, elementor addon, elementor templates, elementor widgets, extensions
Requires at least: 5.7.0
Tested up to: 6.2
Requires PHP: 5.6
Stable tag: 5.2.8
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

Best Elementor Addons with 120+ Elementor FREE Widgets & 300+ Elementor Templates with Mega Menu, Blog Post Grid, Header Footer Builder, WooCommerce Widgets and More.

== Description ==

Introducing The Plus Addons for Elementor with more than <strong>120+ Powerful Widgets & Extension, 300+ UI Essential Blocks & 18+ Ready-to-use templates</strong> with the most advanced functionalities including Blog builder, Woo Builder, Mega Menu, Filtered Gallery and much more to supercharge your Elementor like never before. Whether you're working on your Perfect blog, creating a sale generating online store or building a website for your next big idea, you can do it all with Elementor when you have [The Plus Addons for Elementor](https://theplusaddons.com/).

Enjoy a Complete<strong> No-Code experience</strong> and build everything with your simple mouse clicks. <strong>No Technical knowledge</strong> required, just plug-in and Get Started.Crafted with care and love to seamlessly integrate for smooth & happy workflow to impress your clients. Perfect for <strong>Bloggers, Freelancers, Marketers, Agency Owners, Designers</strong> and anyone who loves using Elementor giving you the freedom to innovate.

| <strong> [ ⚡ SUPERCHARGE MY SITE NOW ](https://theplusaddons.com/)</strong> |

~~~~~~~~~~~~~~~~

<strong> Quick Navigation Links</strong>
[ 🌐 Visit Website](https://theplusaddons.com/) | [ 📹 Video Guides]( https://www.youtube.com/c/POSIMYTHInnovations/?sub_confirmation=1)| [ 📑 Documentations](https://docs.posimyth.com/tpae/) | [ 🛣️ Roadmap](http://roadmap.theplusaddons.com/) | [ 👥 Join Community](https://www.facebook.com/groups/theplus4elementor) |[ 🤝 Free Support](https://wordpress.org/support/plugin/the-plus-addons-for-elementor-page-builder/) | [ ⭐ Premium Support](https://store.posimyth.com/helpdesk/)

 

### 💪 Complete Features Explained Under 4 Mins <a href="https://www.youtube.com/watch?v=yG_oyhz-oAY"> Watch Now</a>

https://www.youtube.com/watch?v=yG_oyhz-oAY

### 👑 Exclusive Features of The Plus Addons

* <strong>Free Blog Builder</strong> for Elementor to customize anything<br><br><br>
* <strong>WooCommerce Store Builder</strong> for Elementor to build custom Checkout, Cart pages, Thank you page etc. 🔥<br><br><br>
* <strong>One-Click Auto Widget Scanner</strong> to Turn off Unused Widgets (Includes Elementor FREE & PRO Widgets too)🚀<br><br><br>
* Regularly Audited by <strong>Top Security Experts</strong> 🔐<a href="https://my.getastra.com/verify/vapt/certificates/71d36c74-6f6a-4fef-9696-26ab5cdf352f"> View Certificate </a><br><br><br>
* <strong>Free Cross-Domain Copy Pasting</strong> to easily copy a piece of content images<br><br><br>
* <strong>FB & Google Events Tracker</strong> to help you track events, button clicks for conversions<br><br><br>
* Vertical and Horizontal <strong>Mega Menu Builder</strong> for Elementor 🔥<br><br><br>
* Display<strong> Facebook and Google Review</strong> directly on your site <br><br><br>
* <strong>Social Feeds</strong> to display content from Facebook, Instagram, YouTube, Twitter, Vimeo 🔥<br><br><br>
* Custom <strong>Login and Signup Form</strong> for Elementor<br><br><br>
* <strong>Carousel Anything</strong> converts any sections in carousel 🔥<br><br><br>
* High converting <strong>Popup Builder</strong> for Elementor Sites<br><br><br>
* Custom <strong>Display/ Visibility Logic</strong> for Elementor 🔥<br><br><br>
* Custom <strong>Elementor Skin Loop Builder</strong> for any Post and CPT 🔥<br><br><br>
* Add <strong>Preloader and Page Transition</strong> to your Elementor sites<br><br><br>
* <strong>Custom Cursor</strong> for Elementor <br><br><br>
* Integrated with <strong>ACF, Toolset, Pods, WooCommerce, Mailchimp </strong> and more<br><br><br>
* <strong>Supports RTL | WPML</strong> or any Translation | <strong>Multisite</strong><br><br><br>
* <strong>Optimized Code Delivery</strong> with <strong>Ultra Light Modular</strong> backend architecture<br><br><br>
* <strong>SEO Friendly,  A/B Tested Designs</strong> and <strong>Mobile Friendly</strong><br><br><br>
* Compatible with most <strong>WordPress themes like <strong>Nexter, Blocksy , Kadence, Astra, OceanWP, GeneratePress, Neve etc.</strong><br><br><br>

and much more explore more below

###🏆 Reviewed and Featured by Top Youtubers 🏆

https://www.youtube.com/watch?v=kXmAQqdkVtg

<em>"This might be the only Elementor Addon you ever need"<strong><a href="https://www.youtube.com/watch?v=kXmAQqdkVtg"> - WP Learning Lab</a></strong></em>


https://www.youtube.com/watch?v=2bdeeu6sZPw

<em>"An amazing plugin,i think it is a kind of full pack addon for elementor"<strong><a href="https://www.youtube.com/watch?v=2bdeeu6sZPw"> - GO TECH UG</a></strong></em>

###Check all our Widgets & Extensions in details below ⤵️

 


###🏆 35+ Free Widgets & Extensions

1. <strong>[Blog Builder](xx)</strong> - Customize everything in your WordPress Blog page template with Elementor to create any type of blog page easily. The only Blog Builder widget set  you will ever need for your WordPress site which includes |  | [Post Title](https://theplusaddons.com/blog-builder/#blog-single) | [Post Content](https://theplusaddons.com/blog-builder/#blog-single) | [Post Featured Image](https://theplusaddons.com/blog-builder/#blog-single) | [Post Meta](https://theplusaddons.com/blog-builder/#blog-single) | [Post Author](https://theplusaddons.com/blog-builder/#blog-single) | [Post Comment](https://theplusaddons.com/blog-builder/#blog-single)
2. <strong> [BlockQuote](https://theplusaddons.com/widgets/blockquote/)</strong> - Highlight quotes, sayings and text content in style with lots of customisation options to play with.
3. <strong>[Buttons](https://theplusaddons.com/widgets/buttons/)</strong> - Proven Styles, Powerful Options and Incredible UX for Most common element of website building, It’s a plus buttons for WordPress using Elementor.
4. <strong>[Countdown](https://theplusaddons.com/widgets/countdown/)</strong> - Create amazing dynamic countdown designs. It’s suitable for coming soon, under maintenance, and other timer sections. Create Urgency to boost sales
5. <strong>[Heading Title](https://theplusaddons.com/widgets/heading-titles/)</strong> - Simple and Multi Purpose Heading title options with magic scroll, tooltip, scroll animation and Full Typography options for WordPress using Elementor.
6. <strong>[Infobox](https://theplusaddons.com/widgets/infobox/)</strong> - Amazing widget to show important information in your website .Infobox is proven and with breakthrough UI/UX element for WordPress using Elementor.
7. <strong>[Navigation Menu Lite](https://theplusaddons.com/widgets/elementor-header-navigation-builder/)</strong> - Using Plain Theme, Theme builder or elementor pro and looking forward to having a navigation menu? Here you go using this option. Create extraordinary navigation bars with unlimited opportunities
8. <strong>[Piechart](https://theplusaddons.com/widgets/piechart/)</strong> - Most basic web elements are designed in a creative way to showcase your charts visually appealing way. Customise Pie Chart in Elementor the way you want and You will have multiple options of Its animations on First Load and Scroll.
9. <strong>[Post Searchs](https://theplusaddons.com/widgets/search-bar/)</strong> - Make all your pages searchable using an amazing search bar widget, which searches using WordPress's main search function. Design with tons of options.
10. <strong>[Pricing Tables](https://theplusaddons.com/widgets/pricing-table/)</strong> - We care for your money, So It’s most amazing and designed based on AB tested philosophies to make it an Elite pricing table for WordPress using Elementor.
11. <strong>[Progress Bar](https://theplusaddons.com/widgets/progress-bar/)</strong> - Use this widget for a multipurpose way to show your progress bar, skill bar, value bar, percentage bar or any other kind of Value in Progress bar format in Elementor using this amazing, versatile and fully customisable widget.
12. <strong>[Social Icon](https://theplusaddons.com/widgets/social-icon/)</strong> - Your handy tool to create amazing social media icons and set up links. It has tons of social icon styles to use in WordPress using Elementor
13. <strong>[Video](https://theplusaddons.com/widgets/videos/)</strong> - Brilliant tool with Powerful options to showcase your Youtube, vimeo and Self-hosted videos in style for WordPress using Elementor.
14. <strong>[Heading Animation](https://theplusaddons.com/widgets/heading-animation/)</strong> - Elite tool to showcase multiple text with incredible typing animations with lots of customisation options for WordPress using Elementor.
15. <strong>[Flipbox](https://theplusaddons.com/widgets/flipbox/)</strong> - Showcase your services and eye-catchy content with most attractive and with powerful UX structure on WordPress using Elementor.
16. <strong>[Smooth Scroll](https://theplusaddons.com/widgets/smooth-scroll/)</strong> - Some pages of your site needs amazing smooth experience. You can do it using this plugin to have a smooth scroll effect for amazing UX in your elementor website.
17. <strong>[Accordions](https://theplusaddons.com/widgets/accordion/)</strong> - Sensational way to showcase your accordions with crafted design styles and options to create uniquely for WordPress using Elementor.
18. <strong>[Tabs/Tours](https://theplusaddons.com/widgets/tabs-tours/)</strong> - Presenting most advanced and powerful Tabs and Tours style collection with unlimited customisation options for WordPress using Elementor.
19. <strong>[Full Page](https://theplusaddons.com/widgets/best-page-scrolling-options-for-elementor/#full-piling)</strong> - This widget is the combination of Full Page JS, Multi Scroll JS, Horizontal Scroll and Page Piling JS. Which are most popular in unique one-page websites.
20. <strong>[Caldera Forms](https://theplusaddons.com/widgets/caldera-forms/)</strong> - Proven Look and Feel of Caldera Forms with elegant improvements to get amazing UI and UX for all your forms in WordPress using Elementor.
21. <strong>[Contact form 7](https://theplusaddons.com/widgets/contact-form-7/)</strong> - Proven Look and Feel of Contact form 7 forms with elegant improvements to get amazing UI and UX for all your forms in WordPress using Elementor.
22. <strong>[Everest Forms](https://theplusaddons.com/widgets/everest-forms/)</strong> - Proven Look and Feel of Everest Forms with elegant improvements to get amazing UI and UX for all your forms in WordPress using Elementor.
23. <strong>[Gravity Forms](https://theplusaddons.com/widgets/gravity-forms/)</strong> - Proven Look and Feel of Gravity Forms with elegant improvements to get amazing UI and UX for all your forms in WordPress using Elementor.
24. <strong>[Ninja Forms](https://theplusaddons.com/widgets/ninja-forms/)</strong> - Proven Look and Feel of Ninja forms with elegant improvements to get amazing UI and UX for all your forms in WordPress using Elementor.
25. <strong>[WP Forms](https://theplusaddons.com/widgets/wpforms/)</strong> - Proven Look and Feel of WP forms with elegant improvements to get amazing UI and UX for all your forms in WordPress using Elementor.
26. <strong>[Blog Posts](https://theplusaddons.com/pluslisting/#plus-blog)</strong> - Supercharge your blog listing layouts and It's customisation options.
[Grid](https://theplusaddons.com/plus-blogs/grid-blogs/) | [Masonry](https://theplusaddons.com/plus-blogs/masonry-blogs/) | [Metro](https://theplusaddons.com/plus-blogs/metro-blogs/) | [Stagger Load](https://theplusaddons.com/plus-blogs/blog-stagger-load/)
27. <strong>[Image Gallery](https://theplusaddons.com/pluslisting/#plus-gallery)</strong> - Advanced Image Gallery styles with tons of options to create creative layouts.
[Grid](https://theplusaddons.com/plus-image-gallery/image-grid/) | [Masonry](https://theplusaddons.com/plus-image-gallery/image-masonry/) | [Metro](https://theplusaddons.com/plus-image-gallery/image-metro/)
28. <strong>[Team Members](https://theplusaddons.com/pluslisting/#Team%20member)</strong> - Team member showcase with some unique concepts with 6+ base styles.
[Grid](https://theplusaddons.com/team-member/#grid-section) | [Masonry](https://theplusaddons.com/team-member/#masonary-section)
29. <strong>[Testimonials](https://theplusaddons.com/pluslisting/#plus-testimonial)</strong> - Collection of 6+ styles of testimonial listing with tons of customisation options to create unique layouts.
[Style 2](https://theplusaddons.com/testimonial/#style-two-carousel) | [Style 4](https://theplusaddons.com/testimonial/#style-four-normal-carousel)
30. <strong>[Client Logos](https://theplusaddons.com/pluslisting/#plus-clients)</strong> - Showcase your company client logos with amazing layout options.
[Grid](https://theplusaddons.com/team-member/#grid-section) | [Masonry](https://theplusaddons.com/widgets/clients/#masonry-layout)
31. <strong>[Equal Height(Developer Friendly)ADVANCED](https://theplusaddons.com/plus-extras/equal-height/)</strong> - Using this option, You can set up equal height for your listing loops as well as with your standard widgets. This can be expanded to long to equal height any same widgets by tracking their div structure or their common CSS class.
32. <strong>[Wrapper Link](https://theplusaddons.com/plus-extras/wrapper-link/)</strong> - You can add link on your whole section/row, Column and any widget using this option. It can be easily added and opened in the same tab or new tab. 
33. <strong>[Age Gate](https://theplusaddons.com/widgets/age-gate/)</strong> - Use an Age gate verification for your Elementor site to protect the content of your site based on age with the date of birth, Yes or No questions
34. <strong>[Message Box](https://theplusaddons.com/widgets/message-box/)</strong> - Create a simple alert box using creative options provided by Message Box widget for Elementor with tons of styling and customization options. Use it on your website to provide a more interactive feel to your users. 
35. <strong> [Advanced Text Block](https://theplusaddons.com/widgets/advance-text-block/)</strong> - Add your most important text content with maximum possible options. It have all cosmetic, typographic and Responsive options as per regular needs.
36. <strong> [Glass Morphism](https://theplusaddons.com/plus-extras/glass-morphism/)</strong> - Get Frosted Glass effect with blur controls to attain GlassMorphism CSS for Free in Elementor. No CSS Coding knowledge required, simply slide to add Blurry Glass effect on any Elementor widgets, section or columns
37. <strong> [Advanced Shadow](https://theplusaddons.com/neumorphism/)</strong> - Create an amazing Shadow effect by providing box shadow, drop shadow and text shadow for any elements of your website using Neumorphism
38. <strong>[Cross Domain Copy Paste](https://theplusaddons.com/plus-extras/cross-domain-copy-paste-and-live-copy-elementor/)</strong> - Use "Plus Copy" to transfer your Elementor Sections, Widgets & Columns from One site to another with simple method. It will change the way you are using Plus Design Templates, You just need to Live Copy from our demo pages and Paste on your website directly.
39. <strong>[Dark Mode](https://theplusaddons.com/widgets/elementor-dark-mode/)</strong> - Best way to create dark mode feature for elementor pages and posts by adding a widget in the footer or header area for best possibilities. It has best in class Night Mode / Dark Mode options with unique switcher options to customise.


### 🏆 75+ Pro Widgets & Extensions

1. <strong>[Audio Player](https://theplusaddons.com/widgets/audio-player/)</strong> - Widget to showcase your single music file or a playlist of music. It can be a must-have widget for the entertainment category’s websites/projects
2. <strong>[Instagram Feed](https://theplusaddons.com/widgets/instagram/)</strong> - Fastest and Easy to configure Instagram feed widget ever made for elementor. You can get feed using an access token or using just a username or the Instagram profile of anyone. Detailed grid options for unlimited customisations and unique layout options for Instagram feed.
3. <strong>[Login/Signup](https://theplusaddons.com/widgets/login-signup-password/)</strong> - Setup WordPress Login form, WordPress member Signup form or/and Forgot password form using one compact elementor widget. Best for WordPress based membership websites.
4. <strong>[Woo- Builder](https://theplusaddons.com/woo-builder/)</strong> -  Create a completely personalised WooCommerce store for your customers without any custom coding. Using our Ultimate WooCommerce Store Builder widget sets
| [My Account Page](https://theplusaddons.com/woo-builder/#my-account) | [Order Track](https://theplusaddons.com/woo-builder/#order-track) | [Woo Cart](https://theplusaddons.com/woo-builder/#cart)  | [WooCheckout](https://theplusaddons.com/woo-builder/#checkout)  | [Woo Single Product Page](https://theplusaddons.com/woo-builder/#single-prodct) | [Woo Single Image](https://theplusaddons.com/woo-builder/#single-prodct) | [Woo Single Pricing](https://theplusaddons.com/woo-builder/#single-prodct) | [Woo Single Tabs](https://theplusaddons.com/woo-builder/#single-prodct) | [Woo Swatches](https://theplusaddons.com/product/ceramic-colored-pots/) | [Woo Thank You Page](https://theplusaddons.com/woo-builder/#thank-you)
5. <strong>[Pricing List](https://theplusaddons.com/widgets/pricing-list/)</strong> - Easiest way to showcase pricing of food menu or any list of items. You can use this for restaurant menus, service lists and other ways using elementor. It can be used versatile way by using Its unique options.
6. <strong>[Protected Content](https://theplusaddons.com/widgets/protected-content/)</strong> - Hide content from website visitors based on a simple passwords, Multiple Passwords, or based on their WordPress user role. You may use that for coupon code options, for client panels and various usages on your website.
7. <strong>[Stylist List](https://theplusaddons.com/widgets/stylish-list/)</strong> - Make a list with great customisation options, Unique layouts and Many value-added options to reach an extra level of design for the stylish list on WordPress using Elementor.
8. <strong>[Table](https://theplusaddons.com/widgets/table/)</strong> - Create Simplest Table in Elementor or Complex Layout needs in elementor, Table widget for elementor will help you in that. It can be useful for all kinds of comparison tables, Pricing Tables, or Busy Table Layouts with tons of options in Elementor.
9. <strong>[Advanced Typography](https://theplusaddons.com/widgets/advanced-typography/)</strong> - Collection of top typography options for elementor such as knockout text, magicscroll typography, text blend mode, arc typography, circular text, underline to hover styles, shadow 3d typography, Vertical text & stroke typography options to create most advanced minimal structures.
10. <strong>[Advanced Buttons](https://theplusaddons.com/widgets/advanced-buttons/)</strong> - Attractive, Easy to use, conversation friendly, and A/B Tested collection of buttons with multi-purpose usability in elementor page builder.
11. <strong>[Advertisement Banner](https://theplusaddons.com/widgets/advrtsment-banner/)</strong> - Make amazing CTA banners for your sale, offers, or any kind of promotional activities. Layer based hover effects make it very unique and eye-popping.
12. <strong>[Animated Separators](https://theplusaddons.com/widgets/advanced-separators/)</strong> - Multiple row/section and column shape dividers with unique options to configure that as per your needs. Style based on wavey JS which you can implement on any place and you can adjust shape separator’s animations and Its shape divider size.
13. <strong>[Animated Service Boxes](https://theplusaddons.com/widgets/animated-service-boxes/)</strong> - Showcase your services, features, and other information in style using this widget of elementor. It can be used as an Animated box, Interactive banners, Info Box, Interactive cards, Animated Features, Interactive box and other ways.
14. <strong>[Before After](https://theplusaddons.com/widgets/before-after-2/)</strong> - Introducing the fastest and easiest way to compare images to showcase before after by horizontal, vertical and opacity based system for WordPress Using Elementor.
15. <strong>[Carousel Anything](https://theplusaddons.com/widgets/carousal-anything/)</strong> - Make your carousels with all stunning options and with the power of templates of elementor. You can use any elementor widgets with various carousal options in this elementor widget.
16. <strong>[Carousel Remote](https://theplusaddons.com/widgets/carousal-remote/)</strong> - Connect and play with any carousel of the plus addons using this widget. You can connect just using a unique id and put this widget anywhere to create some creative layouts.
17. <strong>[Circle Menu](https://theplusaddons.com/widgets/circle-menu/)</strong> - Display your call to action menu with amazing style and based on the open/close method to keep it small in the beginning. It has a bubble menu, flat menu and other variations.
18. <strong>[Creative Images](https://theplusaddons.com/widgets/creative-images/)</strong> - Change the way you put images on websites, Show It with great details effects and animation based on hover/scroll in WordPress using Elementor.
19. <strong>[Draw SVG](https://theplusaddons.com/widgets/draw-svg/)</strong> - You can use draw animation on any SVG in elementor, It can be drawn on the first load or You can set up that on hover draw option. You can draw SVG in Elementor Multiple Ways using multiple options to use from.
20. <strong>[Dynamic Devices](https://theplusaddons.com/widgets/device-dynamic/)</strong> - Love showcasing content inside beautiful laptops, Desktops, Mobiles and Browser Screens? This element is for you.
21. <strong>[Hotspot/Pin Point](https://theplusaddons.com/widgets/hotspot-pin-point/)</strong> - Highlight your points or Create Hot spots on your images to showcase your points. We also have 6+ creatively picked hotspot styles and advanced tooltips with unlimited options to set up in.
22. <strong>[Image Cascading](https://theplusaddons.com/widgets/image-cascading/)</strong> - Biggest and most brilliant plugin for layered images, Sections with layers, Cascading layouts in WordPress using Elementor.
23. <strong>[Lottiefiles Animations](https://theplusaddons.com/widgets/lottiefiles-animations-elementor/)</strong> - Looking animation which are quite engaging and a crafter by the top in class motion designers to use in your next web design project? Try this elementor widget, which will help you to achieve that just by using JSON code made from Lottiefiles.
[Lottiefiles On Scroll](https://theplusaddons.com/widgets/lottiefiles-on-scroll-animation-elementor/)
24. <strong>[Morphing Sections](https://theplusaddons.com/widgets/morphing-sections/)</strong> - Wondering how to make your Blob Shape SVGs with animated morphing shape? This widget of elementor will help you to do Blob SVG Path morphing, Dynamic blob Shape Overlay in Image Gradient and Normal Color. This tool animate blob SVGs and shape morphing in your row and column background.
25. <strong>[Off Canvas](https://theplusaddons.com/widgets/off-canvas/)</strong> - Any Elementor Widget or menu now in a stylish way with the unique variations of Off-Canvas elementor widget. Many customisation options make it unique and multi-purpose in all elementor addons.
26. <strong>[Process/Steps](https://theplusaddons.com/widgets/process-steps/)</strong> - Special Widget made for showcase process/steps with unique layout variations. It have text indicator, special steps styles and more customizability options.
27. <strong>[Scroll Navigation](https://theplusaddons.com/widgets/one-page-scroll-navigation/)</strong> - Best widget for creation of one-page scroll navigation to give the feel of one page and easy to navigate on a long page. It’s the most popular web design trend to have one-page websites and this widget will improve UX by having nice scroll navigation.
28. <strong>[Time line](https://theplusaddons.com/widgets/timeline/)</strong> - All your timeline layout needs will be fulfilled using this widget of elementor. It can be useful for Organisation History Timeline, Startup Storyline, Event/Program History TimeLine, Step by Step Tutorials Timeline, and Lifetime Achievements and many more ways.
29. <strong>[Unfold](https://theplusaddons.com/widgets/unfold-expand-toggle/)</strong> - Hide your content and Expand that on click to show more information. You can use this widget in elementor to show information with title and description as well as with elementor template.
30. <strong>[Row Background](https://theplusaddons.com/widgets/row-background/)</strong> - Sensational piece of code to create premium, layer based and uniquely advanced Section Backgrounds in WordPress using Elementor.
[Gallery Background](https://theplusaddons.com/widgets/row-background/gallery-background/) | [Parallax Background](https://theplusaddons.com/widgets/row-background/parallax-background/) | [Segment Background](https://theplusaddons.com/widgets/row-background/segmentation-background/) | [Special Backgrounds](https://theplusaddons.com/widgets/row-background/special-background/) | [Video Background](https://theplusaddons.com/widgets/row-background/video-background/)
31. <strong>[Switcher](https://theplusaddons.com/widgets/switcher/)</strong> - Introducing amazing content switcher for your pricing table, Info Sections, Services and many other layouts on WordPress using Elementor.
32. <strong>[Page Scroll](https://theplusaddons.com/widgets/best-page-scrolling-options-for-elementor/)</strong> - This widget is the combination of Full Page JS, Multi Scroll JS, Horizontal Scroll and Page Piling JS. Which are most popular in unique one-page websites.
[Page Pilling](https://theplusaddons.com/widgets/best-page-scrolling-options-for-elementor/page-piling/) | [Multi Scroll 50/50](https://theplusaddons.com/widgets/best-page-scrolling-options-for-elementor/multi-scroll/) | [Multi Scroll 30/70](https://theplusaddons.com/widgets/best-page-scrolling-options-for-elementor/multi-scroll-2/) | [Horizontal Scroll Color Change](https://theplusaddons.com/widgets/horizontal-scroll-with-background-color-change/) | [Horizontal Scroll Fix Image Change](https://theplusaddons.com/widgets/horizontal-scroll-with-fix-background-image/) | [Horizontal Scroll Image Change](https://theplusaddons.com/widgets/horizontal-scroll-with-background-image-change/)
33. <strong>[Navigation Builder](https://theplusaddons.com/widgets/elementor-header-navigation-builder/)</strong> - All needs related to navigation and whole header section is covered under our collection of widgets for elementor. You can create a search bar, woocommerce mini cart, music bar, login section, mega menu and many more using this elementor header builder widgets.
[Horizontal Mega Menu](https://theplusaddons.com/widgets/mega-menu/#horizontal-menu) | [Vertical Mega Menu](https://theplusaddons.com/widgets/mega-menu/#vertical-menu) | [Vertical Toggle Mega Menu](https://theplusaddons.com/widgets/mega-menu/#vertical-menu)
34. <strong>[Breadcrumb](https://theplusaddons.com/widgets/breadcrumb-bar/)</strong> - Wondering for amazing tool to showcase your text content? Infobox is proven and with breakthrough UI/UX element for WordPress using Elementor.
35. <strong>[Mobile Menu](https://theplusaddons.com/widgets/mobile-menu/)</strong> - Special elementor widget made for mobile devices, It will give mobile application look and special menu designs for your website in this mobile-first web world.
36. <strong>[Google Map](https://theplusaddons.com/widgets/google-maps/)</strong> - Advanced or simple needs of maps, We have covered all. One of the best elementor google map widgets with lots of options and multiple marker pinpoints.
37. <strong>[Mailchimp Subscription](https://theplusaddons.com/widgets/mailchimp/)</strong> - Amazing Collection of Heading styles for your next project. It has simple yet elegant styles to create unlimited different Looks and Layouts.
38. <strong>[Blog Posts](https://theplusaddons.com/pluslisting/#plus-blog)</strong> - Supercharge your blog listing layouts and It's customisation options.
[Carousel](https://theplusaddons.com/plus-blogs/carousel-blogs/) | [Grid](https://theplusaddons.com/plus-blogs/blog-styles/) | [Filter](https://theplusaddons.com/plus-blogs/blog-filter/) | [Lazy Load](https://theplusaddons.com/plus-blogs/lazy-load-blogs/) | [Load More](https://theplusaddons.com/plus-blogs/load-more-blogs/) | [Messy Columns](https://theplusaddons.com/plus-blogs/masonry-blogs/) | [Pagination](https://theplusaddons.com/plus-blogs/pagination-blogs/)
39. <strong>[Image Gallery](https://theplusaddons.com/pluslisting/#plus-gallery)</strong> - Advanced Image Gallery styles with tons of options to create creative layouts.
[Carousel](https://theplusaddons.com/plus-image-gallery/image-carousel/) | [Filter](https://theplusaddons.com/plus-image-gallery/image-filter/) | [Messy Columns](https://theplusaddons.com/plus-image-gallery/image-messy-columns/) | [ACF Gallery Field](https://theplusaddons.com/pluslisting/elementor-acf-gallery-support/)
40. <strong>[Woo Products](https://theplusaddons.com/pluslisting/#woo-products)</strong> - Amazing Collection of unique product listing styles for WooCommerce.
[Carousel](https://theplusaddons.com/pluslisting/product-carousal/) | [Filter](https://theplusaddons.com/pluslisting/product-filter/) | [Grid](https://theplusaddons.com/pluslisting/product-grid/) | [Lazy Load](https://theplusaddons.com/pluslisting/product-lazy-load/) | [Load More](https://theplusaddons.com/pluslisting/product-load-more/) | [Masonry](https://theplusaddons.com/pluslisting/product-masonry/) | [Messy Columns](https://theplusaddons.com/pluslisting/product-messy-column/) | [Metro](https://theplusaddons.com/pluslisting/product-metro/) | [Pagination](https://theplusaddons.com/pluslisting/product-pagination/) | [Style](https://theplusaddons.com/pluslisting/product-styles/)
41. <strong>[Team Members](https://theplusaddons.com/pluslisting/#Team%20member)</strong> - Team member showcase with some unique concepts with 6+ base styles.
[Carousel layout](https://theplusaddons.com/team-member/#carousal-layout-section) | [Center Mode](https://theplusaddons.com/team-member/#center-mode-section) | [Filter Options](https://theplusaddons.com/team-member/#fIlter-section) | [Messy Columns](https://theplusaddons.com/team-member/#messy-section)
42. <strong>[Testimonials](https://theplusaddons.com/pluslisting/#plus-testimonial)</strong> - Collection of 6+ styles of testimonial listing with tons of customisation options to create unique layouts.
[Center Mode Options](https://theplusaddons.com/testimonial/#center-moder-section) | [Messy Columns](https://theplusaddons.com/testimonial/#messy-columns-section) | [Style 1](https://theplusaddons.com/testimonial/#section-style-one) | [Style 3](https://theplusaddons.com/testimonial/#style-three-normal-carousel)
43. <strong>[Client Logos](https://theplusaddons.com/pluslisting/#plus-clients)</strong> - Showcase your company client logos with amazing layout options.
[CSS Filters](https://theplusaddons.com/widgets/clients/#css-filters) | [Carousel](https://theplusaddons.com/widgets/clients/#carousel-options) | [Center Mode](https://theplusaddons.com/widgets/clients/#center-mode-carousel) | [Lazy Load](https://theplusaddons.com/client-load-more-lazy-load/) | [Load More](https://theplusaddons.com/client-load-more-lazy-load/) | [Messy Columns](https://theplusaddons.com/widgets/clients/#messy-columns) | [Paginations](https://theplusaddons.com/client-pagination/)
44. <strong>[Dynamic Listing Options](https://theplusaddons.com/pluslisting/#plus-dynamic-listing)</strong> - Supercharge your dynamic listing layouts and It's customisation options.
[Custom Loop Skin](https://theplusaddons.com/pluslisting/custom-loop-skin-builder/) | [Dynamic Listing](https://theplusaddons.com/pluslisting/dynamic-listing/) | [ACF Loops](https://theplusaddons.com/pluslisting/#acf-loops) | 
[ACF Repeater Field](https://theplusaddons.com/pluslisting/elementor-acf-repeater-support/)
45. <strong>[Dynamic Category](https://theplusaddons.com/pluslisting/dynamic-category/)</strong> - Show categories or taxonomy listing of any custom post type in style using listing methods like Grid, Masonry, Metro and Carousel options and on top of that, there is options for 3d Parallax, Mouse move parallax and Messy columns.
46. <strong>[Dynamic Smart Showcase](https://theplusaddons.com/pluslisting/#plus-magazine-post-styles)</strong> - Supercharge your dynamic listing layouts and It's customisation options.
[Magazine Slider](https://theplusaddons.com/pluslisting/dynamic-magazine-slider/) | [Magazine Filter](https://theplusaddons.com/pluslisting/dynamic-magazine-filter/) | [Dynamic Ticker](https://theplusaddons.com/pluslisting/dynamic-ticker/)
47. <strong>[Mouse Cursor Icon](https://theplusaddons.com/plus-extras/mouse-cursor-icon-change/)</strong> - Using this widget you can change mouse cursor or icon, setup follow cursor image or you can set up text-based mouse cursor style. Which help your visitors to know about any column or you can improve your UX.
48. <strong>[Mouse Cursor](https://theplusaddons.com/widgets/mouse-cursor-icon-widget/)</strong> - Customize your default mouse pointer with the best custom Mouse Cursor widget for your WordPress site. 
49. <strong>[Blog Builder: Post Navigation & Post Search](https://theplusaddons.com/blog-builder/#blog-single)</strong> Allows you to turn any post into a tool that lets visitors jump to any other post in just one click with Post Navigation. And use
50. <strong>[Preloader & Page Transitions](https://theplusaddons.com/widgets/pre-loader/)</strong> -  Add Preloader in your Elementor site easily via the Preloader widget with Image, Icon, Text, Lottie Files , Custom Code , Shortcodes, Progress and many predefined animations
51. <strong>[Social Feed](https://theplusaddons.com/widgets/social-feed/)</strong> -  Display your Social Feed from Facebook, Instagram, Twitter, YouTube and Vimeo within a few clicks, fetch feed automatically from your social media accounts and get it displayed on your website easily with the best social media widget for WordPress.
52. <strong>[Social Reviews](https://theplusaddons.com/widgets/social-reviews/)</strong> - Add Social Reviews & Badges from Google & Facebook, showing reviews and ratings from your customers is the best way to get someone’s trust. The social reviews widget will automatically connect your social media reviews to your website. Saves you time and a lot of effort.
53. <strong>[Social Sharing](https://theplusaddons.com/widgets/social-sharing/)</strong> - Add Social Sharing Icons on your WordPress website. Easily share your page content over Facebook, Twitter, Google, LinkedIn, WhatsApp, Tumblr, Pinterest, Reddit,  and over 22 more social sharing using this 
54. <strong>[Table of Contents](https://theplusaddons.com/widgets/table-of-contents/)</strong> - Automatically add Table of Contents without any hassle or coding. Create a Dynamic Generated Table of Contents using the best Table of Contents widget for Elementor. Automatically generate the dynamic Table of Contents for your post, page, and custom post type content.
55. <strong>[Number Counter](https://theplusaddons.com/widgets/number-counter/)</strong> - Your all needs covered regarding showcase of numbers. This widget is with all needed options and customisation variations to make your achievements looks at it’s best.
56. <strong>[Source Code Syntax Highlighter](https://theplusaddons.com/widgets/source-code-syntax-highlighter/)</strong> -  When it comes to getting feedback or sharing your code, you need a tool that provides different colour schemes to choose from, depending on multiple codes. Say Hello to syntax highlighting for over 25+ programming languages that can be embedded as a live preview for your WordPress website.
57. <strong>[Plus Search Filters](https://theplusaddons.com/plus-search-filters/)</strong> -  Setup most complex filter websites with ease using Plus Search Filters widget. It will change the way you build your data-rich websites with an elementor page builder.
58. <strong>[Search Bar](https://theplusaddons.com/plus-search-filters/advanced-wp-ajax-searchbar/)</strong> -  No need to go to another page to check your search results. Check that right below your search bar and even that in the most elegant way possible using elementor page builder.
59. <strong>[Column Ordering In Devices](https://theplusaddons.com/plus-extras/elementor-column-improvements-upgrades-responsive/#column-order)</strong> - Now change your column order in different devices. Best for Navigation Menus and Other Creative Layouts.
60. <strong>[Custom Media Query Breakpoints](https://theplusaddons.com/plus-extras/elementor-column-improvements-upgrades-responsive/#media-query-breakpoint)</strong> - Setup Column's Width | Margin | Padding | Visibility | Order Sequence for different breakpoints based on @Media Min/Max Width Value(You Can Add Multiple Values too using Repeater.).
61. <strong>[Column Width(Px,%,Calc())](https://theplusaddons.com/plus-extras/elementor-column-improvements-upgrades-responsive/#column-width)</strong> - Use Pixels | Percentage | Calc Function
62. <strong>[Sticky Column](https://theplusaddons.com/plus-extras/elementor-column-improvements-upgrades-responsive/#sticky-column)</strong> - Make Column Sticky based on height of other columns in row.
63. <strong>[Display/Conditional Rules](https://theplusaddons.com/plus-extras/display-rules/)</strong> - Enable/Disable any Elementor widgets based on multiple conditions and logic, Which gives you enormous possibilities for unique and out of the box logic in Marketing or Web Management Part.
64. <strong>[Global Continuous Effects](https://theplusaddons.com/plus-extras/special-effects-parallax-3d-mouse-hover-continuous-animations-elementor-widgets/#continuous-effects)</strong> - Looking for some amazing effects for each widget? Now, You can use mouse move based parallax in elementor widgets, Special Scroll Overlay dual colour effects, Tilt 3D Hover Effects, and Continuous animation effects in elementor widgets.
65. <strong>[Global Mouse Hover Parallax](https://theplusaddons.com/plus-extras/special-effects-parallax-3d-mouse-hover-continuous-animations-elementor-widgets/#mouse-parallax)</strong> - Looking for some amazing effects for each widget? Now, You can use mouse move based parallax in elementor widgets, Special Scroll Overlay dual colour effects, Tilt 3D Hover Effects, and Continuous animation effects in elementor widgets.
66. <strong>[Global Special Overlay Color](https://theplusaddons.com/plus-extras/special-effects-parallax-3d-mouse-hover-continuous-animations-elementor-widgets/#first-section)</strong> - Looking for some amazing effects for each widget? Now, You can use mouse move based parallax in elementor widgets, Special Scroll Overlay dual colour effects, Tilt 3D Hover Effects, and Continuous animation effects in elementor widgets.
67. <strong>[Global Tilt 3D Effects](https://theplusaddons.com/plus-extras/special-effects-parallax-3d-mouse-hover-continuous-animations-elementor-widgets/#tilt-3d)</strong> - Looking for some amazing effects for each widget? Now, You can use mouse move based parallax in elementor widgets, Special Scroll Overlay dual colour effects, Tilt 3D Hover Effects, and Continuous animation effects in elementor widgets.
68. <strong>[Global Tooltip](https://theplusaddons.com/plus-extras/global-tooltips-elementor-widgets/)</strong> - In today’s two way communication, Tooltips are are popular and increase interactiveness on your website. Best Global tooltip option available in elementor. Tooltips are almost in all possible elementor widgets and with tons of customisation options for tooltips.
69. <strong>[Facebook & Google Event Tracker](https://theplusaddons.com/plus-extras/conversion-event-tracker-in-elementor/)</strong> - This feature is to track all Facebook pixel and google analytics conversion events from your WordPress Website made by Elementor Page Builder. It tracks each tag's click events and Submits button events for form builder widgets.
70. <strong>[White Label](https://theplusaddons.com/plus-extras/white-label-branding/)</strong> - You may change each and every detail of plugin to your own or your client’s. It will give personalisation to your client projects.
71. <strong>[Grid Design Tool](https://theplusaddons.com/plus-extras/design-tool/)</strong> - Multiple elementor designer productivity & testing oriented features, Which help designers to achieve their best possible creative level.
72. <strong>[MagicScroll Integration](https://theplusaddons.com/plus-extras/on-scroll-magic-elementor-parallax/)</strong> - Have you heard about ScrollMagic in Elementor? Most of all of our elementor widgets have ScrollMagic Options in Plus Extras to create unique layouts. This is the best Scroll Magic option available in elementor till now.
73. <strong>[On Scroll Animation Content ](https://theplusaddons.com/plus-extras/on-scroll-animations-elementor-any-widgets/)</strong> - Amazing On Scroll Animations for all your individual widgets of elementor, You can set up one-time scroll animation in elementor widgets or dual scroll animation in elementor widgets. It has more than 30 Animation styles for scroll animation for elementor widgets.
74. <strong>[Row Section Scroll Animation](https://theplusaddons.com/plus-extras/row-section-full-scroll-animation/)</strong> - Looking for Options like 3d Section | Row Animation on scroll, Reveal Animation, Content Fly animation on content, Special Content visibility options from different directions and Other effects based on scroll? Your search will end here using this Elementor widget.
75. <strong>[Custom CSS(Section & Column)](https://theplusaddons.com/plus-extras/elementor-column-improvements-upgrades-responsive/#custom-css)</strong> - Add your custom CSS in any Row/Section or Column
76. <strong>[18+ Premium Templates](https://theplusaddons.com/plus-design/#templates)</strong> - Your website landing page is a few clicks away using our ready-made, responsive website templates. It will have more demos coming very soon.
77. <strong>[ 300+ Premium UI Blocks](https://theplusaddons.com/plus-design/#templates)</strong> - Your website landing page is a few clicks away using our ready-made, responsive website templates. It will have more demos coming very soon.

 

<p><strong>If this Plugin adds value to your business, please share your valuable review ⭐️ ⭐️ ⭐️ ⭐️ ⭐️ to encourage for future improvement.<br>❤️Thank you <a href="https://wordpress.org/support/plugin/the-plus-addons-for-elementor-page-builder/reviews/?filter=5">👉 ADD 5 STAR</a> </strong></p>

###🔍 Check our other Products
<strong><a href="https://theplusblocks.com/">🥇 The Plus Addons for Gutenberg</a></strong> -  Making sites on Gutenberg will never be this easy. With more than 70+ Blocks to build your perfect site.

<strong><a href="https://nexterwp.com/">🥇 NexterWP Theme</a></strong> - Get the complete WordPress experience with Nexter. Build on ultra light architecture with tons of features

== Installation ==
####⚠️ NOTE: This plugin is an extension for Elementor Page Builder
<a href="https://elementor.com/">Elementor Page Builder</a> plugin must be installed and activated to use our plugin.

<h3>☑️ 5 Steps for Installation </h3>
1. Go to <strong>‘Plugins’</strong> option in your dashboard and select <strong>'add new'</strong>
2. Search for <strong>'The Plus Addons for Elementor'</strong> and install it
3. Now You will have all widgets available in your Elementor Panel. You may check categories like “Plus Essential”, “Plus Listing”, “Plus Header” and so on.
4. You may enable/disable widgets & features from The Plus Settings from Dashboard.
5. Congratulation, Now your site is ⚡ SUPERCHARGED, Get ready to build amazing websites

<h3>👉 <a href="https://youtu.be/etIgVcbs_Rc"> Watch this Quick Installation Guide under ⏱️ 60 Seconds</a></h3>

<em> For Gutenberg Block Editor, check <a href="https://wordpress.org/plugins/the-plus-addons-for-block-editor/">The Plus Addons for Gutenberg</a></em>

== Frequently Asked Questions ==

**Does Elementor is required to use this plugin?**

Yes. You need to install & activate the Elementor plugin first to get access to The Plus Addons Widgets & Features.

**Elementor Panel in the editor is freezed and shows a spinning circle.**

Make sure your memory limit is set to 768M or higher, If you have multiple elementor addons installed and you are having an issue with the elementor panel loading icon and freeze.

Is the issue created due to The Plus Addons? No. This is not anyone’s bug/issue. It’s just because, If you want to use more widgets, Your server needs more memory limit to use everything in your backend.

My Hosting Provider doesn’t allow a higher memory limit, What to do? If that is the case, You just need to disable all unused widgets from The Plus Addons and all other addons you have installed. This will reduce the need for the required memory limit as the total number of active widgets will go down.

**Everything is messed up in Backend. Or Everything looks perfectly fine in the Backend but has issues on the frontend.**

Make sure you have removed cache from The Plus Settings → Performance → Purge all cache. Furthermore, remove cache from all your 3rd party cache plugins. Moreover, remove your browser cache by hard reload and/or test your site on incognito mode.

**Your Font Awesome Icons are not visible?**

You need to turn on compatibility for font awesome 4 from Elementor -> Extra Settings.

**My Backend Speed is down after installation of The Plus Addons.**

We do not load any extra files, which will reduce your backend performance. But, If you are having issues with loading in the Elementor panel with more delay, That means You need to increase your memory limit. If you can not increase the memory limit, You need to disable all unused widgets from The Plus Settings ->Plus Widget as well as from all other Addon plugins you have installed on your website.

**My Frontend website loading Speed is down after installation of The Plus Addons.**

We have the most advanced caching architecture, Which will never bloat your site. Know more about our caching architecture. We have some tricks and suggestions to improve frontend performance. 

== Screenshots ==
1. 120+ Advanced Elementor Widgets & Extensions
2. Horizontal & Vertical Mega Menu Builder
3. Ajax Search Bar & 15+ Filters for Posts, CPT & WooCommerce Products
4. Complete WooCommerce Store Builder
5. Custom Loop Skin for Posts, CPT & WooCommerce Products
6. Free Blog/CPT Single Page Builder
7. Full Page, Horizontal, Multi Scrolling Effects & Scroll Sequence
8. Login Signup & Forgot Password Form
9. Advanced Data Tables with Search & Sorting
10. Advanced Dynamic Display Conditions (Exclusive WooCommerce Conditions)
11. Social Feed, Reviews & Embed (6+ Platforms)
12. Unique 22+ Elementor Extensions

== Changelog ==

= 5.2.8 =
Update : Contact Form 7 : Document Link Update
Update : Everest Form : Document Link Update
Update : Gravity Form : Document Link Update
Update : Ninja Form : Document Link Update
Update : WP Form : Document Link Update
Update : Post Comment : Add Controller For Dynamic Content
Fix : Minor bug fixes & Improvements

= 5.2.7 =
Update : Contact Form 7 : UI Improvement
Update : Hover card : Opacity Controller Condition Improvement
Fix : Minor bug fixes & Improvements

= 5.2.6 =
Fix : Minor bug fixes & Improvements

= 5.2.5 =
Add : Contact Form 7 : Add Controller For Radio Button & Check Box Icon size
Update : Pricing Table : Controller Improvement
Fix : Testimonials : Word Break issue 
Fix : Minor bug fixes & Improvements

= 5.2.4 =
Fix : Minor bug fixes & Improvements

= 5.2.3 =
Update : Accordion : Document Link Update
Update : Advanced Text Block : Document Link Update
Update : Meeting Scheduler : Document Link Update
Update : Tabs & Tours : Document Link Update
Update : Countdown : Add Option For Countdown Setup and Style
Fix : Minor bug fixes & Improvements

= 5.2.2 =
Update : Heading Title : Separator Margin Controller Added 
Update : Countdown : Days, Hour, Minutes, Seconds Disable Controller Added
Update : Testimonials : Add Controller Position Y Option For Arrows
Update : Team Member : Box Loop Background Padding Controller Added
Fix : Minor bug fixes & Improvements

= 5.2.1 =
Update : Button : UI Controller Improvement
Update : Blockquote : Drop Cap Quote Description Html Support
Update : Countdown : Controller Improvement
Fix : Minor bug fixes & Improvements

= 5.2.0 =
Update : Gravity Form : Radio and Check box style Controller Improvement	
Update : Progress Bar : Number Controller Css Improvement
Update : Team Member : Controller Improvement
Update : Equal Height : Js & Condition Improvement
Fix : Minor bug fixes & Improvements

= 5.1.18 =
Update : Button : Controller Improvement
Update : Number Counter : Change Controller Normal To Responsive
Update : Tab Tours : Tab Active In Mobile Responsive
Compatibility : Dokan Few Pages Caching Conflict
Fix : Minor bug fixes & Improvements

= 5.1.16 =
Added : Client Listout : In Content Repeater Option
Added : Team Member : In Content Repeater Option
Added : Testimonials : In Content Repeater Option
Update : Team Member : Added Image overlay
Update : Team Member : Social Icon Styling Controller Improvement
Update : Contact Form 7 : Textarea Height Option
Update : Navigation Menu Lite : Mobile Menu Controller Improvement
Fix : Team Member : Post Type Default image
Compatibility : Elementor 3.1.X Free & Pro

= 5.1.15 =
Update : Smooth Scroll : Firefox Compatibility
Update : MetaBox : Condition Improvement
Fix : Minor bug fixes and Improvements

= 5.1.14 =
Added : Post Content : Get WordPress editor content option in single page
Fix : Minor bug fixes and Improvements

= 5.1.13 =
Update : Elementor Beta : Loop Grid Compatibility
Update : POT File Update
Fix : Slick CSS Image URL Bug

= 5.1.12 =
Added : Social Embed Widget
Update : Post Meta : Improved Content Alignment field
Fix : Minor bug fixes and Improvements

= 5.1.11 =
Added : Button Widget
Added : Social Icons Widget
Fix : Minor fixes and Improvements

= 5.1.10 =
Update : Backend Live Copy/Paste JS Improvement
Update : Widget Panel Video & Document Link update
Fix : Minor fixes and Improvements

= 5.1.9 =
Update : Smart Optimised Assets loading : Add action on wp_footer
Update : On Demand Assets loading : Add action on wp_print_footer_scripts
Update : Admin Welcome Page
Fix : Minor fixes and Improvements

= 5.1.8 =
Update : CSS & JS Assets loading improvement for Archive page
Update : Admin Welcome Page Update
Fix : Minor fixes and Improvements

= 5.1.7 =
Compatibility : Elementor 3.7
Update : CSS & JS Assets loading improvement
Update : POT file update
Update : Admin Welcome Page Update
Fix : Minor fix and Improvement

= 5.1.4 =
Update : Elementor Pro Popup Compatibility
Update : Advanced Shadow : CSS & JS loading Improvement Frontend
Update : Admin Welcome Page Update
Update : wp_footer to wp_print_footer_scripts Improvement
Update : Live Copy : add_action elementor/editor/after_enqueue_scripts to elementor/editor/before_enqueue_scripts
Fix : Minor fix and Improvement

= 5.1.3 =
Added : Blockquote : Tweet button with Page URL
Added : Blockquote : Dropcap(First Character) option
Update : Welcome Page Change log Update
Fix : Minor fix and Improvement

= 5.1.2 =
Added : Blockquote : Author Description option
Added : Blockquote : Quote Icon and position dynamic option
Added : Blockquote : Quote Image option
Added : Blockquote : 3 type of Border Layout option
Added : Blockquote : Padding & Margin Responsive option
Fix : Minor fix and Improvement on CSS & JS

= 5.1.1 =
Update : Zero Widget Used Notice in Widget Scanner
Update : Elementor Backend CSS & JS Loading Improvement
Fix : Age Gate : Body Overflow Scroll JS Improvement

= 5.1.0 =
Update : Elementor Widget Manager beta to stable release
Update : Live Copy Paste Icon update
Update : Feature Name Update Display Rules to Display Condition
Update : Caching Algorithm Improvements
Fix : CSS improvement in Slick for Carousel Vertical Layout
Deprecated: Instagram Widget (Instead use Social Feed Widget)

= 5.0.9 =
Compatibility : WordPress 6.0
Compatibility : Elementor Pro 3.7
Update : Container Compatibility : Live Copy
Update : Post Feature Image : Container option in background
Update : Post Meta : Taxonomies Type Option (Category/Tag)
Update : Number Counter : Dynamic Tag option for Number Value, Animation Starting Value and Gap
Update : Advanced Shadow : Container Compatibility
Update : Equal Height : Container Compatibility
Update : Glass Morphism : Container Compatibility
Update : Wrapper Link : Container Compatibility 

= 5.0.8 =
Compatibility : Elementor 3.6 Compatibility Verified & Tag Update

= 5.0.7 =
Fix : Polylang wpml-config.xml conflict fix

= 5.0.6 =
Compatibility : WordPress 5.9
Compatibility : Elementor Compatibility Tag
Added : Cross-Domain Copy Paste
Added : Glass Morphism option in Section
Added : Glass Morphism option in Column
Added : Glass Morphism option in Widget
Added : WPML String Transition XML
Added : Advanced Multi Box Shadow
Added : Advanced Multi Text shadow
Added : Advanced Multi Drop Shadow
Fix : Few Improvements and Bug fix

= 5.0.5 =
Fix : Inner Section Widget not visible bug
Fix : Bug fix and improvements

= 5.0.4 =
Update : Accordion : Font-Awesome Inline compatibility
Update : Age Gate : Font-Awesome Inline compatibility
Update : Button : Font-Awesome Inline compatibility
Update : Flipbox : Font-Awesome Inline compatibility
Update : Messagebox : Font-Awesome Inline compatibility
Update : Postmeta : Font-Awesome Inline compatibility
Update : Scroll Navigation : Font-Awesome Inline compatibility
Compatibility : Compatibility with Elementor v3.4 and Elementor Pro v3.5

= 5.0.3 =
Fix : Scan widget fix in Lightspeed server
Fix : Age Gate JS update for overflow issue in the body
Fix : Bug fix and improvements

= 5.0.2 =
Update : Optimized Caching algorithm
Fix : Control conditions execution bug in the control slug of Elementor 3.4.2.  <a href="https://github.com/elementor/elementor/issues/16003" target="_blank">Reference Link</a>
Fix : Bug fix and improvements

= 5.0.1 =
Added : The Plus Settings -> Plus Widgets -> Unused Widget Scan and Disable Option
Added : Elementor Free & Pro Widgets Manager
Added : The Plus Settings -> Performance -> Elementor Free & Pro Widgets Manager -> Unused Widget Scan and Disable Option
Added : Options to manage inbuilt caching from The Plus Settings -> Performance 1. Smart Advanced Caching 2. On-Demand Assets Loading
Update : Video Player : Schema Markup option
Compatibility : WordPress 5.8 compatibility
Compatibility : Compatibility with Elementor v 3.4

= 5.0.0 =
IMPORTANT : We got audited and approved by Astra Security. <a href="https://my.getastra.com/verify/vapt/certificates/71d36c74-6f6a-4fef-9696-26ab5cdf352f" target="_blank">View Certificate</a>
Added : Age Gate
Added : Message Box
Added : Post Title
Added : Post Content
Added : Post Featured Image
Added : Post Meta
Added : Post Author
Added : Post Comment
Update : CSP (Content Security Policy) implementation & Updates
Fix : JS bug fix and improvements

= 2.0.8 =
Update : Compatibility with Elementor v3.2


= 2.0.7 =
Update : function change wp_redirect to wp_safe_redirect
Fix : JS bug fix and improvements

= 2.0.6 =
Security Fix : Security error related to HTML tags validation (nearly identical to Elementor's Recent Patch)
Fix : JS bug fix and improvements

= 2.0.5 =
Compatibility : WordPress 5.7 compatibility
Compatibility : Elementor Free 3.1.4 compatibility
Compatibility : Elementor Pro 3.2.0 compatibility

= 2.0.4 =
Fix : Demo Importer bug fix

= 2.0.3 =
- COMPATIBILITY : Elementor Free 3.1.1 & Pro 3.0.10
- Fix : Progress Bar : Number Prefix/Postfix bug fix
- Fix : JS bug fix

= 2.0.2 =
- Compatibility : WordPress 5.6 Compatibility & jQuery Updates
- Update : Accordion : Support Icon Library
- Update : Button : Support Icon Library
- Update : Infobox : Support Icon Library
- Update : Flip Box : Support Icon Library
- Fix : JS bug fix

= 2.0.1 =
- Gravity Form Fields Improvements
- Bug Fixes

= 2.0.0 =
- Revamped whole structure
- New Admin Panel UI
- Updated & Included 30+ Widgets
- Added 3+ New Features
- Compatibility with WordPress 5.5
- Compatibility with Elementor 3.X
- Bug Fixes

== Upgrade Notice ==

= 2.0.7 =
Notice : This is a security update. Update it soon. For More details check Changelog.