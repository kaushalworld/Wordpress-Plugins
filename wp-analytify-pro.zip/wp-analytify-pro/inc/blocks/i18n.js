wp.i18n.setLocaleData( { '': {} }, 'wp-analytify-pro' );
