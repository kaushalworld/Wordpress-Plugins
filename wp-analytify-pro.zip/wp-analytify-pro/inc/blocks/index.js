import "./i18n.js";
import "./shortcodes";
import "./excludeTracking";