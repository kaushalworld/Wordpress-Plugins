"use strict";
jQuery( window ).on( 'load', function(){
    document.cookie = 'ihc_payment=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
});
