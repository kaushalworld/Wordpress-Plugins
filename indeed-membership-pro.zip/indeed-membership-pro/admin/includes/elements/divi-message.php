<div class="ihc-error-global-dashboard-message ihc-admin-dashboard-notice-mk-message">
    <div class='ihc-close-notice ihc-js-close-admin-dashboard-mk-notice' data-name="divi">x</div>
    <?php echo esc_html__( "Now you can restrict Divi Content with Ultimate Membership Pro by granting access to specific Memberships or Logged Users only. Check this out: ", 'ihc' );?>
    <a href="<?php echo esc_url('https://store.wpindeed.com/addon/divi-content-locker/');?>" target="_blank">Ultimate Membership Pro - Divi Content Locker</a>
</div>
