<?php

abstract class Brizy_Editor_Asset_StaticFile {

	use Brizy_Editor_Asset_StaticFileTrait;
}
