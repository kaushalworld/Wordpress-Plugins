<?php
 

 return [
    ShopEngine\Core\Service_Providers\Theme_Support_Provider::class,
 ];
