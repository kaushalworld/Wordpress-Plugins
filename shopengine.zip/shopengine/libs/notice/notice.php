<?php

namespace ShopEngine\Libs\Notice;

defined('ABSPATH') || exit;

class Notice
{
    /**
     * scripts version
     *
     * @var string
     */
    protected $script_version = '2.1.1';

    /**
     * Unique ID to identify each notice
     *
     * @var string
     */
    protected $notice_id;

    /**
     * Plugin text-domain
     *
     * @var string
     */
    protected $text_domain;

    /**
     * Unique ID
     *
     * @var string
     */
    protected $unique_id;

    /**
     * Notice div container's class
     *
     * @var string
     */
    protected $class = '';

    /**
     * Single button's data
     *
     * @var array
     */
    protected $button;

    /**
     * Size class
     *
     * @var array
     */
    protected $size = [];

    /**
     * List of all buttons with it's config data
     *
     * @var array
     */
    protected $buttons = [];

    /**
     * Notice title
     *
     * @var string
     */
    protected $title = '';

    /**
     * Notice message
     *
     * @var string
     */
    protected $message = '';

    /**
     * Left logo
     *
     * @var string
     */
    protected $logo = '';
    /**
     * Container gutter
     *
     * @var string
     */
    protected $gutter = true;

    /**
     * Left logo style
     *
     * @var string
     */
    protected $logo_style = '';

    /**
     * Left logo style
     *
     * @var string
     */
    protected $dismissible = false; // false, user, global

    /**
     * @var int
     */
    protected $expired_time = 1;

    /**
     * html markup for notice
     *
     * @var string
     */
    protected $html = '';
	
	/**
	 * 
	 * @var self
	 */
    private static $instance;

    /**
     * Method: instance -> Return Notice module class instance
     *
     * @return self
     */
    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Configures all setter variables
     *
     * @param string $text_domain
     * @param string|null $unique_id
     * @return self
     */
    public function set_config($text_domain, $unique_id = null)
    {
        $this->text_domain = $text_domain;
        $this->unique_id   = is_null($unique_id) ? uniqid() : $unique_id;
        $this->notice_id   = $text_domain . '-' . $unique_id;
        $this->button      = [
            'default_class' => 'button',
            'class'         => 'button-secondary ', // button-primary button-secondary button-small button-large button-link
            'text'          => 'Button',
            'url'           => '#',
            'icon'          => ''
        ];
        return $this;
    }

    /**
     * call after setting all configuration
     * @return void
     */
    public function call()
    {
        add_action('admin_notices', [$this, 'get_notice']);
        add_action('wp_ajax_shopengine-notices', [$this, 'dismiss_ajax_call']);
    }

    /**
     * Adds classes to the container
     *
     * @param  string $classname
     * @return self
     */
    public function set_class($classname = '')
    {
        $this->class .= $classname;
        return $this;
    }

    /**
     * @param string $type
     * @return self
     */
    public function set_type($type = '')
    {
        $this->class .= ' notice-' . $type;
        return $this;
    }

    /**
     * @param array $button
     * @return self
     */
    public function set_button($button = [])
    {
        $button          = array_merge($this->button, $button);
        $this->buttons[] = $button;
        return $this;
    }

    /**
     * @param $id
     * @return self
     */
    public function set_id($id)
    {
        $this->notice_id = $id;
        return $this;
    }

    /**
     * @param string $title
     * @return self
     */
    public function set_title($title = '')
    {
        $this->title .= $title;
        return $this;
    }

    /**
     * @param string $message
     * @return self
     */
    public function set_message($message = '')
    {
        $this->message .= $message;
        return $this;
    }

    /**
     * @param bool $gutter
     * @return self
     */
    public function set_gutter($gutter = true)
    {
        $this->gutter .= $gutter;
        $this->class .= ($gutter === true ? '' : ' no-gutter');
        return $this;
    }

    /**
     * @param string $logo
     * @param string $logo_style
     * @return self
     */
    public function set_logo($logo = '', $logo_style = '')
    {
        $this->logo       = $logo;
        $this->logo_style = $logo_style;
        return $this;
    }

    /**
     * @param string $html
     * @return self
     */
    public function set_html($html = '')
    {
        $this->html .= $html;
        return $this;
    }

    /**
     * @param string $scope
     * @param integer $time
     * @return self
     */
    public function set_dismiss($scope = 'global', $time = (3600 * 24 * 7))
    {
        $this->dismissible  = $scope;
        $this->expired_time = $time;
        return $this;
    }

	/**
     * get_version
     *
     * @return string
     */
    public function get_version()
    {
        return $this->script_version;
    }

    /**
     * get_script_location
     *
     * @return string
     */
    public function get_script_location()
    {
        return __FILE__;
    }

    /**
     * get grouped data
     *
     * @return array
     */
    public function get_data()
    {
        return [
            'message' => $this->message,
            'title'   => $this->title,
            'buttons' => $this->buttons,
            'class'   => $this->class,
            'html'    => $this->html
        ];
    }

    public function get_notice()
    {
        // dismissible conditions
        if ('user' === $this->dismissible) {
            $expired = get_user_meta(get_current_user_id(), $this->notice_id, true);
        } elseif ('global' === $this->dismissible) {
            $expired = get_transient($this->notice_id);
        } else {
            $expired = '';
        }

        global $oxaim_lib_notice_list;

        if (!isset($oxaim_lib_notice_list[$this->notice_id])) {
            $oxaim_lib_notice_list[$this->notice_id] = __FILE__;

            // is transient expired?
            if (false === $expired || empty($expired)) {
                $this->generate_html();
            }
        }
    }

	public function generate_html()
	{
		$this->enqueue_scripts();
 		?>
		<div id="<?php echo esc_attr($this->notice_id); ?>" class="notice wpmet-notice notice-<?php echo esc_attr($this->notice_id . ' ' . $this->class); ?> <?php echo (false === $this->dismissible ? '' : 'is-dismissible'); ?>" expired_time="<?php echo esc_attr($this->expired_time); ?>" dismissible="<?php echo esc_attr($this->dismissible); ?>">
			<?php if (!empty($this->logo)) : ?>
				<img class="notice-logo" style="<?php echo esc_attr($this->logo_style); ?>" src="<?php echo esc_url($this->logo); ?>" alt="<?php esc_attr_e('notice logo','shopengine'); ?>" />
			<?php endif; ?>

			<div class="notice-right-container <?php echo (empty($this->logo) ? 'notice-container-full-width' : ''); ?>">

				<?php if (empty($this->html)) : ?>
					<?php echo (empty($this->title) ? '' : sprintf('<div class="notice-main-title notice-vert-space">%s</div>', esc_html($this->title))); ?>

					<div class="notice-message notice-vert-space">
						<?php echo wp_kses($this->message, \ShopEngine\Utils\Helper::get_kses_array()); ?>
					</div>

					<?php if (!empty($this->buttons)) : ?>
						<div class="button-container notice-vert-space">
							<?php foreach ($this->buttons as $button) : ?>
								<a title="<?php esc_html_e('Notice Details','shopengine')?>" id="<?php echo (!isset($button['id']) ? '' : esc_attr($button['id'])); ?>" <?php echo isset($button['target_blank']) && $button['target_blank'] == true ? 'target="_blank"' : ''; ?> href="<?php echo esc_url($button['url']); ?>" class="wpmet-notice-button <?php echo esc_attr($button['class']); ?>">
									<?php if (!empty($button['icon'])) : ?>
										<i class="notice-icon <?php echo esc_attr($button['icon']); ?>"></i>
									<?php endif; ?>
									<?php echo esc_html($button['text']); ?>
								</a>
								&nbsp;
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

				<?php else : ?>
					<?php echo wp_kses($this->html, \ShopEngine\Utils\Helper::get_kses_array()); ?>
				<?php endif; ?>

			</div>

			<?php if (false !== $this->dismissible) : ?>
				<button type="button" class="notice-dismiss">
					<span class="screen-reader-text">x</span>
				</button>
			<?php endif; ?>

			<div style="clear:both"></div>

		</div>
		<?php
	}

	public function dismiss_ajax_call()
	{
		if (empty($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'shopengine-notices')) {
			return false;
		}

		$notice_id    = (isset($_POST['notice_id'])) ? sanitize_text_field(wp_unslash($_POST['notice_id'])) : '';
		$dismissible  = (isset($_POST['dismissible'])) ? sanitize_text_field(wp_unslash($_POST['dismissible'])) : '';
		$expired_time = (isset($_POST['expired_time'])) ? sanitize_text_field(wp_unslash($_POST['expired_time'])) : '';

		if (!empty($notice_id)) {
			if ('user' === $dismissible) {
				update_user_meta(get_current_user_id(), $notice_id, true);
			} else {
				set_transient($notice_id, true, $expired_time);
			}

			wp_send_json_success();
		}

		wp_send_json_error();
	}

	protected function enqueue_scripts()
	{
		echo "
			<script>
                jQuery(document).ready(function ($) {
                    $( '.wpmet-notice.is-dismissible' ).on( 'click', '.notice-dismiss', function() {

                        _this 		        = $( this ).parents('.wpmet-notice').eq(0);
                        var notice_id 	    = _this.attr( 'id' ) || '';
                        var expired_time 	= _this.attr( 'expired_time' ) || '';
                        var dismissible 	= _this.attr( 'dismissible' ) || '';
                        var x               = $( this ).attr('class');

                        _this.hide();

                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action 	        : 'shopengine-notices',
                                notice_id 		: notice_id,
                                dismissible 	: dismissible,
                                expired_time 	: expired_time,
								nonce 			: '" . esc_js(wp_create_nonce('shopengine-notices')) . "'
                            },
                        });
                    });
                });
            </script>
            <style>
                .wpmet-notice{
                    margin-bottom: 15px;
                    padding: 0!important;
                    display: flex;
                    flex-direction: row;
                    justify-content: flex-start;
                    align-items: center;
                }

                .wpmet-notice .notice-right-container{
                    margin: .7rem .8rem .8rem;
                }

                .notice-container-full-width{
                    width:100%!important;
                }
                
                .wpmet-notice.no-gutter{
                    padding: 0!important;
                    border-width: 0!important;
                }
                .wpmet-notice.no-gutter .notice-right-container{
                    padding: 0!important;
                    margin: 0!important;
                }

                .notice-right-container .notice-vert-space{
                    margin-bottom: .8rem;
                }

                .notice-right-container .notice-vert-space:last-child,
                .notice-right-container .notice-vert-space:only-child{
                    margin-bottom: 0;
                }

                .wpmet-notice .notice-logo{
                    padding: 3px;
                    max-width: 110px;
                    max-height: 110px;
                }
                
                .wpmet-notice-button {
                    text-decoration:none;
                }
                
                .wpmet-notice-button > i{
                    margin-right: 3px;
                }
                
                .wpmet-notice-button .notice-icon{
                    display:inline-block;
                }

                .wpmet-notice-button .notice-icon:before{
                    vertical-align: middle!important;
                    margin-top: -1px;
                }

                .wpmet-notice .notice-main-title{
                    color: #1d2327;
                    font-size: 1.2rem;
                }
             
            </style>
		";
	}
}
