<div class="shopengine-account-details">
	<?php woocommerce_account_edit_account(); ?>
</div>
